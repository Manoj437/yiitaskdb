--
-- Database: `yiitask`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `insertData`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertData` (IN `bsalary` FLOAT(4), IN `commision` INT(10), IN `allowance` FLOAT(4), IN `deduction` FLOAT(4), IN `taxval` FLOAT(4), IN `uid` INT(10))  BEGIN
set @comm= (bsalary*commision)/100;
set @psalary=bsalary+@comm+allowance;
set @tax=(@psalary*taxval)/100;

select @psalary;
select @tax;
select @comm;

insert into accounts (user_id, payable_salary, basic_salary, tax_value) VALUES (uid, @psalary, bsalary, @tax);

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `payable_salary` float DEFAULT NULL,
  `basic_salary` float DEFAULT NULL,
  `tax_value` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `user_id`, `payable_salary`, `basic_salary`, `tax_value`) VALUES
(1, 1, 20000, 15000, 500);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `department_id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(45) NOT NULL,
  `commision` int(10) DEFAULT NULL,
  `allowance` float DEFAULT NULL,
  `deduction` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `commision`, `allowance`, `deduction`) VALUES
(1, 'department_1', 1, 1212.33, 1002),
(2, 'department_2', 2, 3131.44, 333),
(3, 'department_3', 12, 23334.9, 22),
(4, 'department_4', 20, 6733.9, 213123),
(5, 'department_5', 15, 331321, 123123),
(6, 'department_6', 18, 21312300, 2122),
(7, 'department_7', 12, 789992, 67732),
(8, 'department_8', 25, 33222, 222),
(9, 'department_9', 10, 213123, 589),
(10, 'department_10', 30, 213123, 300);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1554594714),
('m130524_201442_init', 1554594739),
('m190124_110200_add_verification_token_column_to_user_table', 1554594740),
('m190407_185000_department_table', 1554667439),
('m190407_193828_taxcharges', 1554667439),
('m190407_200708_userType', 1554667888),
('m190407_201836_user', 1554671066),
('m190407_210705_accounts', 1554671854);

-- --------------------------------------------------------

--
-- Table structure for table `taxcharges`
--

DROP TABLE IF EXISTS `taxcharges`;
CREATE TABLE `taxcharges` (
  `tax_id` int(10) UNSIGNED NOT NULL,
  `salary_upto` float DEFAULT NULL,
  `tax_percentage` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxcharges`
--

INSERT INTO `taxcharges` (`tax_id`, `salary_upto`, `tax_percentage`) VALUES
(1, 100, 1.5),
(2, 500, 2.5),
(3, 1000, 3.6),
(4, 1500, 3.9),
(5, 2000, 4),
(6, 8000, 8.3),
(7, 20000, 9.1),
(8, 50000, 11.9),
(9, 100000, 13.9),
(10, 1000000, 30.9);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type_id` int(10) UNSIGNED NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `first_name`, `last_name`, `email`, `password`, `user_type_id`, `department_id`) VALUES
(1, 'Manoj', 'Verma', 'manoj437@gmail.com', '222222', 5, 10);

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

DROP TABLE IF EXISTS `usertype`;
CREATE TABLE `usertype` (
  `user_type_id` int(10) UNSIGNED NOT NULL,
  `user_type_name` varchar(45) NOT NULL,
  `basic_salary` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`user_type_id`, `user_type_name`, `basic_salary`) VALUES
(1, 'Worker_1', 2000),
(2, 'Worker_2', 5000),
(3, 'Worker_3', 10000),
(4, 'Worker_4', 13000),
(5, 'Worker_5', 15000);

-- --------------------------------------------------------

--
-- Table structure for table `user_old`
--

DROP TABLE IF EXISTS `user_old`;
CREATE TABLE `user_old` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `verification_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_accounts_user_id_accounts` (`user_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `taxcharges`
--
ALTER TABLE `taxcharges`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_user_user_type_id_user` (`user_type_id`),
  ADD KEY `idx_user_department_id_user` (`department_id`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`user_type_id`);

--
-- Indexes for table `user_old`
--
ALTER TABLE `user_old`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `taxcharges`
--
ALTER TABLE `taxcharges`
  MODIFY `tax_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `usertype`
--
ALTER TABLE `usertype`
  MODIFY `user_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_old`
--
ALTER TABLE `user_old`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `fk_accounts_user_id_accounts` FOREIGN KEY (`user_id`) REFERENCES `user` (`uid`) ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_department_id_user` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_user_type_id_user` FOREIGN KEY (`user_type_id`) REFERENCES `usertype` (`user_type_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
